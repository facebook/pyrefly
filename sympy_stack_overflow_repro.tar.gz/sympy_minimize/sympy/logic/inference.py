"""Inference"""
from sympy.logic.boolalg import simplify_logic
