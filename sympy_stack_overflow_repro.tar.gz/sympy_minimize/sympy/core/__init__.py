"""Core module. Provides the basic operations needed in sympy.
"""

from .sympify import sympify, SympifyError
