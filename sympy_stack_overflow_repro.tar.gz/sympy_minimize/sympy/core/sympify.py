"""sympify -- convert objects SymPy internal format"""

from __future__ import annotations

from typing import Any, Callable, overload, TYPE_CHECKING, TypeVar

import mpmath.libmp as mlib

from inspect import getmro
import string
from sympy.core.random import choice

from .parameters import global_parameters

from sympy.utilities.iterables import iterable


if TYPE_CHECKING:

    from sympy.core.basic import Basic
    from sympy.core.expr import Expr
    from sympy.core.numbers import Integer, Float

    Tbasic = TypeVar('Tbasic', bound=Basic)


class SympifyError(ValueError):
    def __init__(self, expr, base_exc=None):
        self.expr = expr
        self.base_exc = base_exc

    def __str__(self):
        if self.base_exc is None:
            return "SympifyError: %r" % (self.expr,)

        return ("Sympify of expression '%s' failed, because of exception being "
            "raised:\n%s: %s" % (self.expr, self.base_exc.__class__.__name__,
            str(self.base_exc)))


converter: dict[type[Any], Callable[[Any], Basic]] = {}

#holds the conversions defined in SymPy itself, i.e. non-user defined conversions
_sympy_converter: dict[type[Any], Callable[[Any], Basic]] = {}

#alias for clearer use in the library
_external_converter = converter

class CantSympify:
    """
    Mix in this trait to a class to disallow sympification of its instances.

    Examples
    ========

    >>> from sympy import sympify
    >>> from sympy.core.sympify import CantSympify

    >>> class Something(dict):
    ...     pass
    ...
    >>> sympify(Something())
    {}

    >>> class Something(dict, CantSympify):
    ...     pass
    ...
    >>> sympify(Something())
    Traceback (most recent call last):
    ...
    SympifyError: SympifyError: {}

    """

    __slots__ = ()


def _is_numpy_instance(a):
    """
    Checks if an object is an instance of a type from the numpy module.
    """
    # This check avoids unnecessarily importing NumPy.  We check the whole
    # __mro__ in case any base type is a numpy type.
    return any(type_.__module__ == 'numpy'
               for type_ in type(a).__mro__)


def _convert_numpy_types(a, **sympify_args):
    """
    Converts a numpy datatype input to an appropriate SymPy type.
    """
    import numpy as np
    if not isinstance(a, np.floating):
        if np.iscomplex(a):
            return _sympy_converter[complex](a.item())
        else:
            return sympify(a.item(), **sympify_args)
    else:
        from .numbers import Float
        prec = np.finfo(a).nmant + 1
        # E.g. double precision means prec=53 but nmant=52
        # Leading bit of mantissa is always 1, so is not stored
        if np.isposinf(a):
            return Float('inf')
        elif np.isneginf(a):
            return Float('-inf')
        else:
            p, q = a.as_integer_ratio()
            a = mlib.from_rational(p, q, prec)
            return Float(a, precision=prec)


@overload
def sympify(a: int, *, strict: bool = False) -> Integer: ... # type: ignore
