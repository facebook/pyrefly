"""A module for solving all kinds of equations.
