"""A functions module, includes all the standard functions.
